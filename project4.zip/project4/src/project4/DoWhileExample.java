package project4;

public class DoWhileExample {
	int i=1;
	do
	{
	System.out.println(i);
	i++;
	}
	while(i<=10);
	}

}
