package project6;

public class Dog {
	String breed;
	   int age;
	   String color;

	   void barking() {
	   }
	   void hungry() {
	   }

	   void sleeping() {
	   }}




