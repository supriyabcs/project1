package project7;

public class X {
		   public void methodX()
		   {
		     System.out.println("Class X method");
		   }
		}



